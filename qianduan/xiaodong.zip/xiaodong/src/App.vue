<template>
  <router-view />
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
body.global-background {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #c8d9f8, #b8a8ff);
  height: 100vh;
  overflow: hidden;
}
</style>